const express=require('express');
const mongoose=require('mongoose');
const schema=mongoose.Schema;

const ProductSchema=new schema({
    id:{
        type:Number,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    mobile_no:{
        type:Number,
        required:true
    },
    image:{
        type:String,
        required:false
    },
    status:{
        type:Number
    },
    created_at:{
        type:Date,default:Date.now
    }
})

const ProductModel=new mongoose.model('product',ProductSchema);

module.exports=ProductModel;